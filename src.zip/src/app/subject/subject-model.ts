export class Subject{
    public constructor(public sub_id:number,public sub_title:string,public sub_desc:string,public fk_faculty_id:number,
    public fk_course_id:number){

    }
}