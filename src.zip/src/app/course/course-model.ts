export class Course{
    public constructor(public course_id:number,public course_title:string,public course_desc:string,public course_duration,public course_fees){
        
    }
}