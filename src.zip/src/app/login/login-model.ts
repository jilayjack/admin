export class Login{
    public constructor(public admin_email_id:string,public pass:string){

    }
}